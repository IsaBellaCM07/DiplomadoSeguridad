package co.edu.uniquindio.ingesis.domain;

public enum Rol {
    USER, // Rol por defecto para usuarios normales
    ADMIN // Rol para administradores
    ;


}