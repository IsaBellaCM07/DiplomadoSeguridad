package co.edu.uniquindio.ingesis.dto;

import co.edu.uniquindio.ingesis.domain.Rol;
import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.util.Objects;

import co.edu.uniquindio.ingesis.domain.Rol;
import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.*;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

import java.time.LocalDate;
import java.util.Objects;

public record UserRegistrationRequest(
        // Ejemplo para el email
        @NotBlank(message = "El campo es requerido")
        @Email(message = "Debe ser un email válido")
        String email,

        // Ejemplo para la clave
        @NotBlank(message = "El campo es requerido")
        @Pattern(regexp = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).*$", message = "Debe contener al menos un número, una letra minúscula y una mayúscula")
        @Size(min = 8, message = "La longitud mínima es 8")
        String clave,

        @NotBlank(message = "El campo es requerido")
        @Size(max = 100, message = "No debe exceder los 100 caracteres")
        String usuario,

        Rol rol // Campo para el rol del usuario
) {
    // Asignación del valor por defecto al rol si no se proporciona
    public UserRegistrationRequest {
        // Asegurarse de que si el rol es null, se asigna el rol de "USER"
        rol = Objects.requireNonNullElse(rol, Rol.USER);
    }
}
