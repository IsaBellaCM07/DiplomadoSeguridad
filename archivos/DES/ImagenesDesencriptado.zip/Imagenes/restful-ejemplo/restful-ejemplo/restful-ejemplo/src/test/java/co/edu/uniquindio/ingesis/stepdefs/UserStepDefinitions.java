package co.edu.uniquindio.ingesis.stepdefs;

import io.cucumber.java.en.*;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class UserStepDefinitions {

    private Response response;

    @Given("la API está disponible")
    public void la_api_esta_disponible() {
        baseURI = "http://localhost:8080"; // Asegúrate que la app esté corriendo
    }

    @When("envío una solicitud POST a {string} con el siguiente cuerpo:")
    public void envio_solicitud_post_con_cuerpo(String endpoint, String body) {
        response = given()
                .header("Content-Type", "application/json")
                .body(body)
                .when()
                .post(endpoint);
    }

    @Then("la respuesta debe tener el código {int}")
    public void la_respuesta_debe_tener_codigo(int statusCode) {
        assertThat(response.getStatusCode(), is(statusCode));
    }
}
